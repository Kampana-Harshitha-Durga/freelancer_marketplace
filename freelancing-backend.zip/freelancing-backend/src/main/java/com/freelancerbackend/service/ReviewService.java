package com.freelancerbackend.service;

import com.freelancerbackend.entity.Review;
import com.freelancerbackend.exception.ResourceNotFoundException;
import com.freelancerbackend.repository.ReviewRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewService {

    private final ReviewRepository reviewRepository;

    // Constructor Injection
    public ReviewService(ReviewRepository reviewRepository) {
        this.reviewRepository = reviewRepository;
    }

    // ===== Get all reviews =====
    public List<Review> getAllReviews() {
        return reviewRepository.findAll();
    }

    // ===== Get review by ID =====
    public Review getReviewById(Long id) {
        return reviewRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Review not found with id: " + id));
    }

    // ===== Create a new review =====
    public Review createReview(Review review) {
        return reviewRepository.save(review);
    }

    // ===== Update an existing review =====
    public Review updateReview(Long id, Review reviewDetails) {
        // Fetch existing review
        Review existingReview = reviewRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Review not found with id: " + id));

        // Update fields (ensure these fields exist in Review.java)
        existingReview.setRating(reviewDetails.getRating());
        existingReview.setComment(reviewDetails.getComment());

        // Save updated review
        return reviewRepository.save(existingReview);
    }

    // ===== Delete a review =====
    public void deleteReview(Long id) {
        Review existingReview = reviewRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Review not found with id: " + id));
        reviewRepository.delete(existingReview);
    }
}
