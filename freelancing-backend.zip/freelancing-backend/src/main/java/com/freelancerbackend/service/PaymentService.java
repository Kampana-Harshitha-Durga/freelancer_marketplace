package com.freelancerbackend.service;

import com.freelancerbackend.entity.Payment;
import com.freelancerbackend.exception.ResourceNotFoundException;
import com.freelancerbackend.repository.PaymentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;

    // Constructor injection
    public PaymentService(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    // ===== Get all payments =====
    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    // ===== Get a payment by ID =====
    public Payment getPaymentById(Long id) {
        return paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found with id: " + id));
    }

    // ===== Create a new payment =====
    public Payment createPayment(Payment payment) {
        return paymentRepository.save(payment);
    }

    // ===== Update an existing payment =====
    public Payment updatePayment(Long id, Payment paymentDetails) {
        // Fetch the existing payment
        Payment existingPayment = paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found with id: " + id));

        // Update fields (make sure these fields exist in Payment.java)
        existingPayment.setAmount(paymentDetails.getAmount());
        existingPayment.setStatus(paymentDetails.getStatus());
        existingPayment.setPaymentDate(paymentDetails.getPaymentDate());

        // Save and return updated payment
        return paymentRepository.save(existingPayment);
    }

    // ===== Delete a payment =====
    public void deletePayment(Long id) {
        Payment existingPayment = paymentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found with id: " + id));
        paymentRepository.delete(existingPayment);
    }
}
