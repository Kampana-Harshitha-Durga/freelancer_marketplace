package com.freelancerbackend.service;


import org.springframework.stereotype.Service;
import com.freelancerbackend.repository.JobRepository;
import com.freelancerbackend.entity.Job;
import com.freelancerbackend.exception.ResourceNotFoundException;

import java.util.List;

@Service
public class JobService {
    private final JobRepository jobRepository;

    public JobService(JobRepository jobRepository) {
        this.jobRepository = jobRepository;
    }

    public Job createJob(Job job) {
    	
        job.setStatus("OPEN");
        return jobRepository.save(job);
    }

    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    public Job getJobById(Long id) {
        return jobRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Job not found with id " + id));
    }
}
