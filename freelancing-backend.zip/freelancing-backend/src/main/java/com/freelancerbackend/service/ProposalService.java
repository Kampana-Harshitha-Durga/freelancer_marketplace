package com.freelancerbackend.service;

import com.freelancerbackend.entity.Proposal;
import com.freelancerbackend.exception.ResourceNotFoundException;
import com.freelancerbackend.repository.ProposalRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProposalService {

    private final ProposalRepository proposalRepository;

    // Constructor Injection
    public ProposalService(ProposalRepository proposalRepository) {
        this.proposalRepository = proposalRepository;
    }

    // ===== Get all proposals =====
    public List<Proposal> getAllProposals() {
        return proposalRepository.findAll();
    }

    // ===== Get a proposal by ID =====
    public Proposal getProposalById(Long id) {
        return proposalRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Proposal not found with id: " + id));
    }

    // ===== Create a new proposal =====
    public Proposal createProposal(Proposal proposal) {
        return proposalRepository.save(proposal);
    }

    // ===== Update an existing proposal =====
    public Proposal updateProposal(Long id, Proposal proposalDetails) {
        // Find the existing proposal
        Proposal existingProposal = proposalRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Proposal not found with id: " + id));

        // Update fields (ensure these fields exist in Proposal.java)
        existingProposal.setDescription(proposalDetails.getDescription());
        existingProposal.setAmount(proposalDetails.getAmount());
        existingProposal.setStatus(proposalDetails.getStatus());

        // Save and return updated proposal
        return proposalRepository.save(existingProposal);
    }

    // ===== Delete a proposal =====
    public void deleteProposal(Long id) {
        Proposal existingProposal = proposalRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Proposal not found with id: " + id));
        proposalRepository.delete(existingProposal);
    }
}
