package com.freelancerbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FreelancingBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FreelancingBackendApplication.class, args);
	}

}
