package com.freelancerbackend.repository;

import com.freelancerbackend.entity.Proposal;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProposalRepository extends JpaRepository<Proposal, Long> {

    // If you want to find proposals by Proposal.userId:
    List<Proposal> findByUserId(Long userId);

    // OR, if your Job entity has freelancerId:
    // List<Proposal> findByJob_FreelancerId(Long freelancerId);
}
