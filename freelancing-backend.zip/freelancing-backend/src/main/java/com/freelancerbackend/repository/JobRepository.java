package com.freelancerbackend.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import com.freelancerbackend.entity.Job;

import java.util.List;

public interface JobRepository extends JpaRepository<Job, Long> {
    List<Job> findByStatus(String status); // Find jobs by status (OPEN, IN_PROGRESS, COMPLETED)
}

