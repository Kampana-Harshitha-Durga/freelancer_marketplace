package com.freelancerbackend.controller;

import com.freelancerbackend.entity.Proposal;
import com.freelancerbackend.service.ProposalService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/proposals")
@CrossOrigin(origins = "*")
public class ProposalController {

    private final ProposalService proposalService;

    // Constructor Injection
    public ProposalController(ProposalService proposalService) {
        this.proposalService = proposalService;
    }

    // Get all proposals
    @GetMapping
    public List<Proposal> getAllProposals() {
        return proposalService.getAllProposals();
    }

    // Get proposal by ID
    @GetMapping("/{id}")
    public Proposal getProposal(@PathVariable Long id) {
        return proposalService.getProposalById(id);
    }

    // Create a new proposal
    @PostMapping
    public Proposal createProposal(@RequestBody Proposal proposal) {
        return proposalService.createProposal(proposal);
    }

    // Update an existing proposal
    @PutMapping("/{id}")
    public Proposal updateProposal(@PathVariable Long id, @RequestBody Proposal proposal) {
        return proposalService.updateProposal(id, proposal);
    }

    // Delete a proposal
    @DeleteMapping("/{id}")
    public void deleteProposal(@PathVariable Long id) {
        proposalService.deleteProposal(id);
    }
}
