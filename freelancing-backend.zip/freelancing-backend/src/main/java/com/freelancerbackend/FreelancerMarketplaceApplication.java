package com.freelancerbackend;

public class FreelancerMarketplaceApplication {

}
