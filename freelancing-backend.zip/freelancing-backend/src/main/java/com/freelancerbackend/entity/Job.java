package com.freelancerbackend.entity;


import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "jobs")
public class Job {
	  @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    private String title;
	    private String description;
	    private Double budget;
	    private String status; // Add this field

	    @ManyToOne
	    @JoinColumn(name = "client_id")
	    private User client;

	    @OneToMany(mappedBy = "job")
	    private List<Proposal> proposals;

	    @OneToOne(mappedBy = "job")
	    private Payment payment;

	    @OneToMany(mappedBy = "job")
	    private List<Review> reviews;

	    // Getters and Setters
	    public Long getId() { return id; }
	    public void setId(Long id) { this.id = id; }

	    public String getTitle() { return title; }
	    public void setTitle(String title) { this.title = title; }

	    public String getDescription() { return description; }
	    public void setDescription(String description) { this.description = description; }

	    public Double getBudget() { return budget; }
	    public void setBudget(Double budget) { this.budget = budget; }

	    public String getStatus() { return status; }       // getter
	    public void setStatus(String status) { this.status = status; } // setter

	    public User getClient() { return client; }
	    public void setClient(User client) { this.client = client; }

	    public List<Proposal> getProposals() { return proposals; }
	    public void setProposals(List<Proposal> proposals) { this.proposals = proposals; }

	    public Payment getPayment() { return payment; }
	    public void setPayment(Payment payment) { this.payment = payment; }

	    public List<Review> getReviews() { return reviews; }
	    public void setReviews(List<Review> reviews) { this.reviews = reviews; }
	}