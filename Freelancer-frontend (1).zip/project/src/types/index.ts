export interface User {
  id: string;
  email: string;
  full_name: string;
  user_type: 'client' | 'freelancer';
  avatar_url?: string;
  created_at: string;
}

export interface FreelancerProfile {
  id: string;
  user_id: string;
  title: string;
  bio: string;
  skills: string[];
  hourly_rate: number;
  portfolio_items: PortfolioItem[];
  rating: number;
  reviews_count: number;
  completed_projects: number;
}

export interface PortfolioItem {
  id: string;
  title: string;
  description: string;
  image_url?: string;
  project_url?: string;
  technologies: string[];
}

export interface Job {
  id: string;
  client_id: string;
  title: string;
  description: string;
  category: string;
  budget_min: number;
  budget_max: number;
  project_type: 'fixed' | 'hourly';
  skills_required: string[];
  status: 'open' | 'in_progress' | 'completed' | 'cancelled';
  proposals_count: number;
  created_at: string;
  client?: User;
}

export interface Proposal {
  id: string;
  job_id: string;
  freelancer_id: string;
  cover_letter: string;
  bid_amount: number;
  estimated_duration: string;
  status: 'pending' | 'accepted' | 'rejected';
  created_at: string;
  freelancer?: User & { freelancer_profile?: FreelancerProfile };
}

export interface Project {
  id: string;
  job_id: string;
  client_id: string;
  freelancer_id: string;
  status: 'active' | 'completed' | 'cancelled';
  budget: number;
  start_date: string;
  end_date?: string;
  milestones: Milestone[];
}

export interface Milestone {
  id: string;
  project_id: string;
  title: string;
  description: string;
  amount: number;
  status: 'pending' | 'in_progress' | 'completed' | 'approved';
  due_date: string;
}

export interface Message {
  id: string;
  project_id: string;
  sender_id: string;
  content: string;
  created_at: string;
  sender?: User;
}

export interface Review {
  id: string;
  project_id: string;
  reviewer_id: string;
  reviewee_id: string;
  rating: number;
  comment: string;
  created_at: string;
}