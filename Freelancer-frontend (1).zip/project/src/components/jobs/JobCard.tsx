import React from 'react';
import { Job } from '../../types';
import { Clock, DollarSign, MapPin, Users } from 'lucide-react';
import { Link } from 'react-router-dom';

interface JobCardProps {
  job: Job;
}

const JobCard: React.FC<JobCardProps> = ({ job }) => {
  const formatBudget = (min: number, max: number) => {
    if (min === max) return `$${min}`;
    return `$${min} - $${max}`;
  };

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    return `${diffDays} days ago`;
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-shadow p-6">
      <div className="flex justify-between items-start mb-4">
        <div className="flex-1">
          <Link 
            to={`/jobs/${job.id}`}
            className="text-lg font-semibold text-gray-900 hover:text-blue-600 transition-colors"
          >
            {job.title}
          </Link>
          <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
            <div className="flex items-center space-x-1">
              <DollarSign className="h-4 w-4" />
              <span>{formatBudget(job.budget_min, job.budget_max)}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Clock className="h-4 w-4" />
              <span>{job.project_type === 'fixed' ? 'Fixed Price' : 'Hourly'}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Users className="h-4 w-4" />
              <span>{job.proposals_count} proposals</span>
            </div>
          </div>
        </div>
        <span className="text-xs text-gray-400">{getTimeAgo(job.created_at)}</span>
      </div>

      <p className="text-gray-600 text-sm mb-4 line-clamp-3">
        {job.description}
      </p>

      <div className="flex flex-wrap gap-2 mb-4">
        {job.skills_required.slice(0, 4).map((skill, index) => (
          <span
            key={index}
            className="inline-block bg-blue-50 text-blue-700 text-xs px-2 py-1 rounded-full"
          >
            {skill}
          </span>
        ))}
        {job.skills_required.length > 4 && (
          <span className="text-xs text-gray-500">
            +{job.skills_required.length - 4} more
          </span>
        )}
      </div>

      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
            <span className="text-sm font-medium text-gray-600">
              {job.client?.full_name?.charAt(0)}
            </span>
          </div>
          <span className="text-sm text-gray-600">{job.client?.full_name}</span>
        </div>
        
        <Link
          to={`/jobs/${job.id}`}
          className="bg-blue-600 text-white px-4 py-2 rounded-md text-sm hover:bg-blue-700 transition-colors"
        >
          View Details
        </Link>
      </div>
    </div>
  );
};

export default JobCard;