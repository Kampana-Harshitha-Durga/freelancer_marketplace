import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import Header from './components/common/Header';
import LandingPage from './components/landing/LandingPage';
import SignUpForm from './components/auth/SignUpForm';
import SignInForm from './components/auth/SignInForm';
import JobList from './components/jobs/JobList';
import FreelancerDashboard from './components/dashboard/FreelancerDashboard';
import ClientDashboard from './components/dashboard/ClientDashboard';

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  return user ? <>{children}</> : <Navigate to="/signin" />;
};

const DashboardRoute: React.FC = () => {
  const { userProfile } = useAuth();
  
  if (!userProfile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }
  
  return userProfile.user_type === 'freelancer' ? <FreelancerDashboard /> : <ClientDashboard />;
};

const AppRoutes: React.FC = () => {
  const { user } = useAuth();

  return (
    <Router>
      <div className="App">
        <Header />
        <Routes>
          <Route path="/" element={user ? <Navigate to="/dashboard" /> : <LandingPage />} />
          <Route path="/signup" element={user ? <Navigate to="/dashboard" /> : <SignUpForm />} />
          <Route path="/signin" element={user ? <Navigate to="/dashboard" /> : <SignInForm />} />
          <Route path="/jobs" element={<JobList />} />
          <Route 
            path="/dashboard" 
            element={
              <ProtectedRoute>
                <DashboardRoute />
              </ProtectedRoute>
            } 
          />
          {/* Placeholder routes */}
          <Route path="/freelancers" element={<div className="p-8 text-center">Freelancers page coming soon!</div>} />
          <Route path="/how-it-works" element={<div className="p-8 text-center">How it works page coming soon!</div>} />
          <Route path="/post-job" element={<div className="p-8 text-center">Post job page coming soon!</div>} />
          <Route path="/profile" element={<div className="p-8 text-center">Profile page coming soon!</div>} />
        </Routes>
      </div>
    </Router>
  );
};

function App() {
  return (
    <AuthProvider>
      <AppRoutes />
    </AuthProvider>
  );
}

export default App;